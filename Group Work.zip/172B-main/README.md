﻿# Acoustic Classification

# Set-up

1. Install **PostGreSQL** (I use PGAdmin)
2. Create file "sql_credentials.py" with the following customized content:
```
 sql_credentials = {
    'host':'localhost',
    'dbname':'172b',
    'user':'postgres',
    'password':'password',
    'port':'5433'
}
```
4. Download datasets from the below links and move folders into code repo (make sure they're included in .gitignore)
- [IDMT](https://www.kaggle.com/datasets/omkarmb/idmt-traffic-dataset/code)
- [MVD](https://github.com/Ashhad785/MVD)
4. Run hydrate_sql.py (loads data into database)
5. Run transform_signals.py (extracts features and loads into database)
6. Run train_models.py (trains model on extracted features)
